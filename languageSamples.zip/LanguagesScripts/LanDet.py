import tkinter as tk
from tkinter import messagebox
import speech_recognition as sr
import pycld2 as cld2
from langdetect import detect, DetectorFactory

# Make langdetect more consistent
DetectorFactory.seed = 0

def detect_language(text):
    try:
        # Primary: Try CLD2
        is_reliable, text_bytes_found, details = cld2.detect(text)
        if len(details) > 0:
            language_name = details[0][0]
            lang_code = details[0][1]
            confidence = details[0][2]
            return language_name, lang_code, confidence, text
        else:
            raise ValueError("CLD2 returned no details.")
    except Exception:
        try:
            # Fallback: Try langdetect
            fallback_code = detect(text)
            return "Fallback (langdetect)", fallback_code, "N/A", text
        except Exception as e:
            return f"Error: {str(e)}", "??", 0, text

def detect_language_from_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        status_label.config(text="Listening...")
        window.update()
        try:
            audio = recognizer.listen(source, timeout=5)
            status_label.config(text="Processing...")
            spoken_text = recognizer.recognize_google(audio)

            # Debug print
            print(f"[DEBUG] Transcribed text: {spoken_text}")

            language_name, lang_code, confidence, text = detect_language(spoken_text)

            result_label.config(
                text=f"Detected: {language_name} ({lang_code})\nText: {text}\nConfidence: {confidence}"
            )
            status_label.config(text="Ready")
        except sr.WaitTimeoutError:
            messagebox.showerror("Timeout", "No speech detected. Try again.")
            status_label.config(text="Ready")
        except sr.UnknownValueError:
            messagebox.showerror("Error", "Sorry, could not understand the audio.")
            status_label.config(text="Ready")
        except Exception as e:
            messagebox.showerror("Error", str(e))
            status_label.config(text="Ready")

# --- GUI Setup ---

window = tk.Tk()
window.title("Voice Language Detector")
window.geometry("400x280")

title_label = tk.Label(window, text="🎤 Speak to Detect Language", font=("Helvetica", 16))
title_label.pack(pady=10)

status_label = tk.Label(window, text="Ready", fg="blue")
status_label.pack()

detect_button = tk.Button(
    window,
    text="Start Listening",
    command=detect_language_from_speech,
    bg="#007acc",
    fg="white",
    font=("Helvetica", 12)
)
detect_button.pack(pady=20)

result_label = tk.Label(window, text="", wraplength=350, justify="left", font=("Helvetica", 12))
result_label.pack(pady=10)

window.mainloop()
