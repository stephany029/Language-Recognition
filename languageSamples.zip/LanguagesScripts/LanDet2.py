import tkinter as tk
from tkinter import messagebox
import speech_recognition as sr
import pycld2 as cld2
from langdetect import detect, DetectorFactory

# Make langdetect more consistent
DetectorFactory.seed = 0

def detect_language(text):
    try:
        # Step 1: Custom model
        x = vectorizer.transform([text])
        lang_code = clf.predict(x)[0]
        print(f"[DEBUG] Custom model detected: {lang_code}")

        if lang_code not in ["en", "fr", "es", "hat"]:
            raise ValueError("Uncertain prediction, trying fallback...")

        return "Custom Model", lang_code, "100%", text

    except Exception as e:
        print(f"[DEBUG] Custom model failed: {str(e)}")

        # Step 2: Try pycld2
        try:
            is_reliable, _, details = cld2.detect(text)
            language_name = details[0][0]
            lang_code = details[0][1]
            confidence = details[0][2]
            return "CLD2", lang_code, f"{confidence}%", text
        except Exception as e2:
            print(f"[DEBUG] CLD2 failed: {str(e2)}")

            # Step 3: Try langdetect
            try:
                fallback_code = detect(text)
                return "Langdetect", fallback_code, "unknown", text
            except Exception as e3:
                return f"Error: {str(e3)}", "??", 0, text


def detect_language_from_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        status_label.config(text="Listening...")
        window.update()
        try:
            audio = recognizer.listen(source, timeout=5)
            status_label.config(text="Processing...")
            spoken_text = recognizer.recognize_google(audio)

            # Debug print
            print(f"[DEBUG] Transcribed text: {spoken_text}")

            language_name, lang_code, confidence, text = detect_language(spoken_text)

            result_label.config(
                text=f"Detected: {language_name} ({lang_code})\nText: {text}\nConfidence: {confidence}"
            )
            status_label.config(text="Ready")
        except sr.WaitTimeoutError:
            messagebox.showerror("Timeout", "No speech detected. Try again.")
            status_label.config(text="Ready")
        except sr.UnknownValueError:
            messagebox.showerror("Error", "Sorry, could not understand the audio.")
            status_label.config(text="Ready")
        except Exception as e:
            messagebox.showerror("Error", str(e))
            status_label.config(text="Ready")

# --- GUI Setup ---

window = tk.Tk()
window.title("Voice Language Detector")
window.geometry("400x280")

title_label = tk.Label(window, text="🎤 Speak to Detect Language", font=("Helvetica", 16))
title_label.pack(pady=10)

status_label = tk.Label(window, text="Ready", fg="blue")
status_label.pack()

detect_button = tk.Button(
    window,
    text="Start Listening",
    command=detect_language_from_speech,
    bg="#007acc",
    fg="white",
    font=("Helvetica", 12)
)
detect_button.pack(pady=20)

result_label = tk.Label(window, text="", wraplength=350, justify="left", font=("Helvetica", 12))
result_label.pack(pady=10)

window.mainloop()
