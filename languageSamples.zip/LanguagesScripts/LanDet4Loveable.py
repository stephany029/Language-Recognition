import tkinter as tk
from tkinter import messagebox, ttk
import speech_recognition as sr
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
import subprocess
import pycld2 as cld2
from langdetect import detect, DetectorFactory
import threading
import pygame
import time
import os
from gtts import gTTS

# Language Detection Seed Consistency
DetectorFactory.seed = 0

# Initialize pygame mixer for audio playback
pygame.mixer.init()

class VoiceAssistantApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Multilingual Voice Assistant")
        self.root.geometry("700x500")
        self.root.configure(bg="#f0f4f8")
        
        # Set theme colors
        self.primary_color = "#6366f1"  # Indigo
        self.secondary_color = "#8b5cf6"  # Violet
        self.bg_color = "#f0f4f8"  # Light gray-blue
        self.text_color = "#1e293b"  # Slate-800
        self.accent_color = "#4f46e5"  # Darker indigo
        
        # Load custom model and vectorizer
        try:
            self.clf = joblib.load("custom_lang_model.pkl")
            self.vectorizer = joblib.load("custom_vectorizer.pkl")
            print("Successfully loaded language models")
        except Exception as e:
            print(f"Error loading models: {e}")
            messagebox.showerror("Model Error", f"Could not load language models: {e}")
            self.clf = None
            self.vectorizer = None
        
        self.setup_ui()
        self.conversation = []
        self.is_listening = False
        self.current_language = "en"  # Default language
        
    def setup_ui(self):
        # Main frame
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Style configuration
        style = ttk.Style()
        style.configure("TFrame", background=self.bg_color)
        style.configure("TButton", 
                        background=self.primary_color, 
                        foreground="white", 
                        font=("Helvetica", 12, "bold"),
                        padding=10)
        style.configure("Header.TLabel", 
                        font=("Helvetica", 16, "bold"), 
                        foreground=self.primary_color,
                        background=self.bg_color)
        style.configure("Status.TLabel", 
                        font=("Helvetica", 10), 
                        foreground=self.accent_color,
                        background=self.bg_color)
        
        # Header
        header_frame = ttk.Frame(main_frame)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        title_label = ttk.Label(header_frame, 
                              text="🌍 Multilingual Voice Assistant", 
                              style="Header.TLabel")
        title_label.pack(side=tk.LEFT)
        
        self.language_label = ttk.Label(header_frame, 
                                     text="", 
                                     font=("Helvetica", 12, "bold"),
                                     foreground=self.secondary_color,
                                     background=self.bg_color)
        self.language_label.pack(side=tk.RIGHT)
        
        # Chat display (conversation history)
        chat_frame = ttk.Frame(main_frame)
        chat_frame.pack(fill=tk.BOTH, expand=True, pady=10)
        
        self.chat_display = tk.Text(chat_frame, 
                                 wrap=tk.WORD,
                                 font=("Helvetica", 11),
                                 background="white",
                                 foreground=self.text_color,
                                 relief=tk.FLAT,
                                 height=15)
        self.chat_display.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)
        self.chat_display.config(state=tk.DISABLED)  # Make it read-only
        
        # Add scrollbar to chat display
        scrollbar = ttk.Scrollbar(chat_frame, command=self.chat_display.yview)
        scrollbar.pack(fill=tk.Y, side=tk.RIGHT)
        self.chat_display.config(yscrollcommand=scrollbar.set)
        
        # Status indicator
        status_frame = ttk.Frame(main_frame)
        status_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.status_label = ttk.Label(status_frame, 
                                   text="Ready", 
                                   style="Status.TLabel")
        self.status_label.pack(side=tk.LEFT)
        
        # Animation canvas for visual feedback
        self.animation_canvas = tk.Canvas(status_frame, 
                                     width=30, 
                                     height=30, 
                                     background=self.bg_color,
                                     highlightthickness=0)
        self.animation_canvas.pack(side=tk.RIGHT)
        self.animation_obj = None
        
        # Bottom control panel
        control_frame = ttk.Frame(main_frame)
        control_frame.pack(fill=tk.X, pady=10)
        
        # Microphone button with custom styling
        self.mic_button_frame = tk.Frame(control_frame, 
                                    background=self.primary_color, 
                                    relief=tk.RAISED,
                                    borderwidth=0)
        self.mic_button_frame.pack(pady=10)
        
        self.mic_button = tk.Button(self.mic_button_frame,
                               text="🎙️ Start Listening",
                               command=self.toggle_listening,
                               font=("Helvetica", 12, "bold"),
                               background=self.primary_color,
                               foreground="white",
                               activebackground=self.accent_color,
                               activeforeground="white",
                               width=20,
                               height=2,
                               relief=tk.FLAT,
                               borderwidth=0,
                               cursor="hand2")
        self.mic_button.pack(padx=2, pady=2)
        
        # Add hover effect to button
        self.mic_button.bind("<Enter>", lambda e: self.on_button_hover(True))
        self.mic_button.bind("<Leave>", lambda e: self.on_button_hover(False))
    
    def on_button_hover(self, is_hovering):
        """Change button color on hover"""
        if is_hovering:
            self.mic_button.config(background=self.secondary_color)
            self.mic_button_frame.config(background=self.secondary_color)
        else:
            self.mic_button.config(background=self.primary_color)
            self.mic_button_frame.config(background=self.primary_color)
    
    def update_status(self, message, is_listening=False):
        """Update status label and animate if listening"""
        self.status_label.config(text=message)
        
        # Clear any existing animation
        if self.animation_obj:
            self.animation_canvas.delete(self.animation_obj)
        
        if is_listening:
            # Draw animated recording indicator
            self.animate_recording()
        else:
            # Draw static indicator
            self.animation_obj = self.animation_canvas.create_oval(
                5, 5, 25, 25, 
                fill="gray", 
                outline=self.bg_color
            )
    
    def animate_recording(self):
        """Animate a recording indicator"""
        # Delete old animation object if exists
        if self.animation_obj:
            self.animation_canvas.delete(self.animation_obj)
        
        # Calculate size based on sine wave for pulsing effect
        time_val = time.time() * 5
        size_factor = abs(int(5 * (1 + 0.3 * time.time() % 2)))
        
        # Draw new circle with changing color
        self.animation_obj = self.animation_canvas.create_oval(
            10-size_factor, 10-size_factor, 
            20+size_factor, 20+size_factor, 
            fill="#ef4444", 
            outline=self.bg_color
        )
        
        # Schedule next animation frame if still listening
        if self.is_listening:
            self.root.after(100, self.animate_recording)
    
    def toggle_listening(self):
        """Start or stop listening to speech"""
        if self.is_listening:
            self.is_listening = False
            self.mic_button.config(text="🎙️ Start Listening")
            self.update_status("Ready")
        else:
            self.is_listening = True
            self.mic_button.config(text="⏹️ Stop Listening")
            self.update_status("🎙️ Listening...", is_listening=True)
            
            # Start listening in a separate thread to avoid UI freezing
            threading.Thread(target=self.listen_to_speech, daemon=True).start()
    
    def add_message(self, text, sender="user"):
        """Add a message to the chat display"""
        self.chat_display.config(state=tk.NORMAL)
        
        # Insert separator if not the first message
        if self.chat_display.get("1.0", tk.END).strip():
            self.chat_display.insert(tk.END, "\n\n")
        
        # Format and insert message
        if sender == "user":
            self.chat_display.insert(tk.END, "You: ", "user_tag")
            self.chat_display.insert(tk.END, text)
        else:
            self.chat_display.insert(tk.END, "Assistant: ", "assistant_tag")
            self.chat_display.insert(tk.END, text)
        
        # Configure tags
        self.chat_display.tag_configure("user_tag", 
                                    foreground=self.primary_color,
                                    font=("Helvetica", 11, "bold"))
        self.chat_display.tag_configure("assistant_tag", 
                                    foreground=self.secondary_color,
                                    font=("Helvetica", 11, "bold"))
        
        # Scroll to bottom
        self.chat_display.config(state=tk.DISABLED)
        self.chat_display.see(tk.END)
    
    def listen_to_speech(self):
        """Record and process speech"""
        recognizer = sr.Recognizer()
        
        try:
            with sr.Microphone() as source:
                # Adjust for ambient noise
                recognizer.adjust_for_ambient_noise(source, duration=0.5)
                
                # Listen to audio
                audio = recognizer.listen(source, timeout=5, phrase_time_limit=10)
                
                # Update status while processing
                self.root.after(0, lambda: self.update_status("Processing speech..."))
                
                try:
                    # Recognize speech using Google Speech Recognition
                    text = recognizer.recognize_google(audio)
                    
                    # Process the recognized text
                    self.root.after(0, lambda: self.process_speech(text))
                    
                except sr.UnknownValueError:
                    self.root.after(0, lambda: self.update_status("Could not understand audio"))
                    self.root.after(0, lambda: self.toggle_listening())
                    
                except sr.RequestError as e:
                    error_msg = f"Speech recognition service error: {e}"
                    self.root.after(0, lambda: self.update_status(error_msg))
                    self.root.after(0, lambda: self.toggle_listening())
                    
        except Exception as e:
            error_msg = f"Error: {str(e)}"
            self.root.after(0, lambda: self.update_status(error_msg))
            self.root.after(0, lambda: self.toggle_listening())
    
    def detect_language(self, text):
        """Detect the language of text using multiple methods"""
        try:
            # Try custom model first (if available)
            if self.clf and self.vectorizer:
                x = self.vectorizer.transform([text])
                lang_code = self.clf.predict(x)[0]
                if lang_code in ["en", "fr", "es", "hat"]:
                    return "Custom Model", lang_code, "100%", text
            
            # Try CLD2
            try:
                is_reliable, _, details = cld2.detect(text)
                return "CLD2", details[0][1], f"{details[0][2]}%", text
            except Exception:
                pass
            
            # Try langdetect
            try:
                lang_code = detect(text)
                return "Langdetect", lang_code, "Unknown", text
            except Exception:
                pass
                
        except Exception as e:
            print(f"Language detection error: {e}")
            
        # Default to English if all else fails
        return "Default", "en", "Unknown", text
    
    def process_speech(self, text):
        """Process speech text, detect language and get AI response"""
        if not text:
            self.update_status("No speech detected")
            self.toggle_listening()
            return
        
        # Add user message to chat
        self.add_message(text, "user")
        
        # Detect language
        detector, lang_code, confidence, processed_text = self.detect_language(text)
        self.current_language = lang_code
        
        # Update language display
        lang_name = self.get_language_name(lang_code)
        self.language_label.config(text=f"🌐 {lang_name} ({lang_code}) - {confidence}")
        
        # Update status
        self.update_status(f"Detected {lang_name} via {detector}. Getting response...")
        
        # Get response from Gemma in a separate thread
        threading.Thread(
            target=self.get_gemma_response,
            args=(text, lang_code),
            daemon=True
        ).start()
    
    def get_language_name(self, lang_code):
        """Convert language code to full name"""
        language_map = {
            "en": "English",
            "es": "Spanish",
            "fr": "French",
            "hat": "Haitian Creole",
            "de": "German",
            "it": "Italian",
            "pt": "Portuguese",
            "nl": "Dutch",
            "ru": "Russian",
            "zh": "Chinese",
            "ja": "Japanese",
            "ko": "Korean",
            "ar": "Arabic",
            "hi": "Hindi"
        }
        return language_map.get(lang_code, f"Unknown ({lang_code})")
    
    def get_gemma_response(self, text, lang_code):
        """Get response from Gemma AI"""
        try:
            # Create language-specific prompt
            if lang_code == "en":
                prompt = f"""You are a helpful multilingual assistant. 
                The user is speaking English. 
                Respond in English to the following: "{text}"
                Keep your answer helpful and concise."""
            elif lang_code == "es":
                prompt = f"""Eres un asistente multilingüe. 
                El usuario está hablando en español.
                Responde en español a lo siguiente: "{text}"
                Mantén tu respuesta útil y concisa."""
            elif lang_code == "fr":
                prompt = f"""Tu es un assistant multilingue.
                L'utilisateur parle français.
                Réponds en français à ce qui suit : "{text}"
                Garde ta réponse utile et concise."""
            elif lang_code == "hat":
                prompt = f"""Ou se yon asistan miltileng.
                Moun nan ap pale kreyòl ayisyen.
                Reponn an kreyòl pou sa: "{text}"
                Kenbe repons ou a senp e itil."""
            else:
                # Default to English for unrecognized languages
                prompt = f"""You are a helpful multilingual assistant.
                Respond to the following text: "{text}"
                Keep your answer helpful and concise."""
            
            # Call Gemma via subprocess
            result = subprocess.run(
                ["ollama", "run", "gemma3:1b"],
                input=prompt.encode("utf-8"),
                capture_output=True,
                timeout=30
            )
            
            # Process response
            gemma_response = result.stdout.decode("utf-8").strip()
            
            # Update UI with the response
            self.root.after(0, lambda: self.add_message(gemma_response, "assistant"))
            self.root.after(0, lambda: self.update_status("Ready"))
            self.root.after(0, lambda: self.toggle_listening())
            
            # Speak the response
            self.speak_text(gemma_response, lang_code)
            
        except Exception as e:
            error_msg = f"Gemma error: {str(e)}"
            print(error_msg)
            self.root.after(0, lambda: self.update_status(error_msg))
            self.root.after(0, lambda: self.toggle_listening())
    
    def speak_text(self, text, lang_code):
        """Convert text to speech and play it"""
        try:
            # Map language code to gTTS format
            tts_lang_code = lang_code
            if lang_code == "hat":
                tts_lang_code = "fr"  # Use French for Haitian Creole as fallback
            
            # Create and save speech file
            tts = gTTS(text=text, lang=tts_lang_code, slow=False)
            
            # Create temp dir if it doesn't exist
            if not os.path.exists("temp"):
                os.makedirs("temp")
                
            # Save and play audio
            tts_file = "temp/response.mp3"
            tts.save(tts_file)
            
            # Play using pygame
            pygame.mixer.music.load(tts_file)
            pygame.mixer.music.play()
            
        except Exception as e:
            print(f"Text-to-speech error: {e}")

# Run the application
if __name__ == "__main__":
    root = tk.Tk()
    app = VoiceAssistantApp(root)
    root.mainloop()