import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
import joblib

# Path to your LanguageSamples folder
data_dir = "languageSamples"

texts = []
labels = []

# Load all text samples
for filename in os.listdir(data_dir):
    lang_code = filename.split(".")[0]
    with open(os.path.join(data_dir, filename), encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                texts.append(line)
                labels.append(lang_code)

# Train the model
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(texts)
clf = MultinomialNB()
clf.fit(X, labels)

# Save the model and vectorizer
joblib.dump(clf, "custom_lang_model.pkl")
joblib.dump(vectorizer, "custom_vectorizer.pkl")

print("✅ Model trained and saved successfully.")
