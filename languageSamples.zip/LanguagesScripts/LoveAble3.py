import tkinter as tk
import threading
import subprocess
import os
from gtts import gTTS
import pygame

pygame.mixer.init()

class VoiceAssistantApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Multilingual Voice Assistant")
        self.language_label = tk.Label(root, text="Language")
        self.language_label.pack()
        self.status_label = tk.Label(root, text="Ready")
        self.status_label.pack()
        self.chat_display = tk.Text(root, height=15, width=60)
        self.chat_display.pack()
        self.should_stop_listening = threading.Event()

    def add_message(self, message, sender="assistant"):
        self.chat_display.insert(tk.END, f"{sender.title()}: {message}\n")
        self.chat_display.see(tk.END)

    def update_status(self, message):
        self.status_label.config(text=message)

    def process_speech(self, text):
        if not text:
            fallback = "I'm sorry, I didn't catch that. Can you please repeat?"
            self.add_message(fallback, "assistant")
            self.update_status("Ready")
            self.speak_text(fallback, "en")
            return

        detector, lang_code, confidence, _ = self.detect_language(text)
        self.current_language = lang_code
        lang_name = self.get_language_name(lang_code)
        self.language_label.config(text=f"🌐 {lang_name} ({lang_code}) - {confidence}")
        self.update_status(f"Detected {lang_name} via {detector}. Getting response...")
        threading.Thread(target=self.get_gemma_response, args=(text, lang_code), daemon=True).start()

    def get_language_name(self, lang_code):
        language_map = {
            "en": "English", "es": "Spanish", "fr": "French", "hat": "Haitian Creole",
            "de": "German", "it": "Italian", "pt": "Portuguese", "nl": "Dutch",
            "ru": "Russian", "zh": "Chinese", "ja": "Japanese", "ko": "Korean",
            "ar": "Arabic", "hi": "Hindi"
        }
        return language_map.get(lang_code, f"Unknown ({lang_code})")

    def detect_language(self, text):
        try:
            from langdetect import detect, DetectorFactory
            DetectorFactory.seed = 0
            lang_code = detect(text)
            return "Langdetect", lang_code, "Unknown", text
        except:
            return "Default", "en", "Unknown", text

    def get_gemma_response(self, text, lang_code):
        try:
            prompts = {
                "en": f"You are a helpful multilingual assistant. The user said: '{text}'. Respond concisely without repeating it.",
                "es": f"Eres un asistente multilingüe. El usuario dijo: '{text}'. Responde de forma concisa sin repetir lo que dijo.",
                "fr": f"Tu es un assistant multilingue. L'utilisateur a dit : '{text}'. Réponds de manière concise sans répéter ce qu'il a dit.",
                "hat": f"Ou se yon asistan miltileng. Itilizatè a di: '{text}'. Reponn san repete sa yo di a."
            }
            prompt = prompts.get(lang_code, f"You are a helpful assistant. Respond to: '{text}'")
            result = subprocess.run(["ollama", "run", "gemma3:1b"], input=prompt.encode("utf-8"), capture_output=True, timeout=30)
            gemma_response = result.stdout.decode("utf-8").strip()
            self.root.after(0, lambda: self.add_message(gemma_response, "assistant"))
            self.root.after(0, lambda: self.speak_text(gemma_response, lang_code))
            self.root.after(0, lambda: self.update_status("Ready"))
        except Exception as e:
            self.root.after(0, lambda: self.update_status(f"Gemma error: {e}"))

    def speak_text(self, text, lang_code):
        try:
            tts_lang_code = "fr" if lang_code == "hat" else lang_code
            if not os.path.exists("temp"):
                os.makedirs("temp")
            tts = gTTS(text=text, lang=tts_lang_code, slow=False)
            tts.save("temp/response.mp3")
            pygame.mixer.music.load("temp/response.mp3")
            pygame.mixer.music.play()
        except Exception as e:
            print(f"Text-to-speech error: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = VoiceAssistantApp(root)
    root.mainloop()
